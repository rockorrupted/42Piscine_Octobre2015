ldapwhoami -Q | cut -d ':' -f2
