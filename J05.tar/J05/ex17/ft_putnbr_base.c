/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: salassam <salassam@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/11/02 19:32:17 by salassam          #+#    #+#             */
/*   Updated: 2015/12/26 12:01:16 by salassam         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

int		mpc(char c)
{
	ft_putchar(c);
	return (0);
}

int		mpn(int n, int b, char *base)
{
	n = (n < 0 ? mpc('-') - n : n);
	return (n < b ? mpc(base[n]) : mpn(n / b, b, base) + mpc(base[n % b]));
}

int		len_ok(char *base)
{
	char	*ans;
	char	*n;

	ans = base - 1;
	while (*(++ans))
	{
		if (*base == '+' || *base == '-' || *base < '!' || *base > '~')
			return (0);
		n = base - 1;
		while (++n < ans)
			if (*n == *ans)
				return (0);
	}
	return (ans - base);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	b;

	b = len_ok(base);
	if (b > 1)
		mpn(nbr, b, base);
}
